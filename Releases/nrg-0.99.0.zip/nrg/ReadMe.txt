﻿
NRG
---
Very simple addon which displays a battery pack (the power button), which starts counting when mp5 is on cooldown.

No config, no switches, no nothing. Well almost: you can move the power button byt shift+drag.


Version history:
----------------
1.0.0: Initial version.

