﻿
NRG
---
Very simple addon which displays a battery pack (the power button), which starts counting when mp5 is on cooldown.

No config, no switches, no nothing. Well almost: you can move the power button by shift+drag.


Version history:
----------------
NRG version 1.2.1
* Updated spell detection; aura refreshment caused by zoning no longer triggers an event.


NRG version 1.2.0
* Lowered the update rate by 1/4; saving CPU ressources


NRG version 1.1.0
* Filtering events, so only magic events are now considered.
  Still not perfect but far better than before: dismounting does no longer trigger mp5 cooldown for example!
* Added a new switch: /nrg size <N> where N can be in a range from 1 to 15. The power button will resize accordingly.
  The default size is 3.
* Added a text on the power button when mana increases.
  The tick show any increment in mana from mp5, spirit, innervate, potions ...


NRG version 1.0.0
* Initial version.

