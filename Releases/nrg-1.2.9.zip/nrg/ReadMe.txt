﻿
NRG
---
Very simple addon which displays a battery pack (the power button), which starts counting when mp5 is on cooldown.

No config, no switches, no nothing. Well almost: you can move the power button by shift+drag.


Version history:
----------------
NRG version 1.2.9
* Bumped Classic client version to 1.15.4


NRG version 1.2.8
* Bumped Classic client version to 1.15.3


NRG version 1.2.7
* Bumped Classic client version to 1.15.2


NRG version 1.2.6
* Bumped Classic client version to 1.15.1


NRG version 1.2.5
* Bumped Wrath client version to 3.4.3
* Bumped Classic client version to 1.15.0


NRG version 1.2.4
* Bumped Wrath client version to 3.4.2
* Bumped Classic client version to 1.14.4


NRG version 1.2.3
* Fixed LUA error while initializing addon.
* Removed retail support after Shadowlands went live.


NRG version 1.2.2
* Fixed LUA error, caused by a reference to the NRG configuration, which does not exist.
* Added (untestet) support for WotLK


NRG version 1.2.1
* Updated spell detection; aura refreshment caused by zoning no longer triggers an event.


NRG version 1.2.0
* Lowered the update rate by 1/4; saving CPU ressources


NRG version 1.1.0
* Filtering events, so only magic events are now considered.
  Still not perfect but far better than before: dismounting does no longer trigger mp5 cooldown for example!
* Added a new switch: /nrg size <N> where N can be in a range from 1 to 15. The power button will resize accordingly.
  The default size is 3.
* Added a text on the power button when mana increases.
  The tick show any increment in mana from mp5, spirit, innervate, potions ...


NRG version 1.0.0
* Initial version.

